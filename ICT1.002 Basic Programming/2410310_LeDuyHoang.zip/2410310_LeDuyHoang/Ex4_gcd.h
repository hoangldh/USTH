#ifndef GCD_H
#define GCD_H

int gcd(int a, int b);

#endif