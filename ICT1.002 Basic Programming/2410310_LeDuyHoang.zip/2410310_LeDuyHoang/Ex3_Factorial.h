#ifndef FACTORIAL.H
#define FACTORIAL.H

long factorial(int n);

#endif